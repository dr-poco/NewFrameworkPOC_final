import sys

sys.path.append("/app/mount/scripts/pyscripts/pylib_control_monitoring/")
import json
import logging
from datetime import datetime, timedelta
from string import Template
from types import SimpleNamespace

import control_monitor_framework as cmf
from pyspark.sql import SparkSession
from pyspark.sql.types import IntegerType, StringType, StructField, StructType, TimestampType
from pyspark.sql.utils import AnalysisException


class ExceptionHandler:
    """Provide utility methods for extracting clean error messages from exceptions.

    - Handle Spark SQL-specific exceptions like AnalysisException and ParseException.
    - Return simplified, readable error messages for logging or debugging.
    - Use static methods to allow usage without instantiating the class.
    """

    @staticmethod
    def extract_error_message(exception):
        """Extract a clean error message from Spark SQL or general exceptions."""
        if isinstance(exception, AnalysisException):
            return exception.desc.split(";")[0].strip()
        if exception.__class__.__name__ == "ParseException":
            return str(exception).split("\n")[0].strip()
        return str(exception).split("\n")[0].strip()

class DataFrameLogger:
    """Manage structured logging for Spark DataFrame operations.

    - Initialize a default log dictionary with metadata fields.
    - Provide methods to update, retrieve, and persist logs.
    - Support schema generation for writing logs to a Spark table.
    """

    def __init__(self):
        """Initialize the logger with a predefined set of log fields.

        - Create a dictionary to store metadata for each query of execution.
        - Set default values to None for all fields.
        """
        self.log_dict = {
            "log_id": None,
            "dag_name": None,
            "dag_run_id": None,
            "spark_job_name": None,
            "job_name": None,
            "job_run_id": None,
            "query_name": None,
            "run_date": None,
            "src_query_file_path": None,
            "tgt_owner": None,
            "tgt_table": None,
            "tgt_strategy": None,
            "start_time": None,
            "end_time": None,
            "status": None,
            "row_count": None,
            "tgt_total_cols": None,
            "loaded_by": None,
            "log_entry_time": None,
            "query_description": None,
            "query_config": None,
            "exception_message": None,
            # "bdp_date_id": None
            'bdp_ingestion_id': None
        }

    def get_log_schema(self):
        """Return the schema definition for the dpf_processing_log Spark DataFrame.

        This schema defines fields used to log metadata from execution querys including timing,
        status, source and target table info, and partitioning by date.

        Returns:
            StructType: A Spark StructType object representing the expected schema.

        """
        log_schema = StructType([
            StructField("log_id", StringType(), True),
            StructField("dag_name", StringType(), True),
            StructField("dag_run_id", IntegerType(), True),
            StructField("spark_job_name", StringType(), True),
            StructField("job_name", StringType(), True),
            StructField("job_run_id", IntegerType(), True),
            StructField("query_name", StringType(), True),
            StructField("run_date", StringType(), True),
            StructField("src_query_file_path", StringType(), True),
            StructField("tgt_owner", StringType(), True),
            StructField("tgt_table", StringType(), True),
            StructField("tgt_strategy", StringType(), True),
            StructField("start_time", TimestampType(), True),
            StructField("end_time", TimestampType(), True),
            StructField("status", StringType(), True),
            StructField("row_count", IntegerType(), True),
            StructField("tgt_total_cols", IntegerType(), True),
            StructField("loaded_by", StringType(), True),
            StructField("log_entry_time", TimestampType(), True),
            StructField("query_description", StringType(), True),
            StructField("query_config", StringType(), True),
            StructField("exception_message", StringType(), True),
            # StructField("bdp_date_id", IntegerType(), True)
            StructField("bdp_ingestion_id", IntegerType(), True)
        ])

        return log_schema
    def add_log(self, key, value):
        """Update the log dictionary with the provided key and value. Only predefined keys will be updated."""
        if key in self.log_dict:
            self.log_dict[key] = value

    def get_log(self):
        """Return the complete log dictionary."""
        return self.log_dict

    def post_logs(self, target_db, table_name, status):
        """Write the current log entry to the specified Spark table.

        - Generate a unique log ID and timestamp.
        - Update status and partition ID fields.
        - Create a Spark DataFrame using the log schema and insert into the table.
        - Log success message upon completion.
        """
        schema = self.get_log_schema()
        epoch = int(datetime.now().timestamp())
        self.log_dict["log_id"] = f"{self.log_dict['dag_run_id']}-{self.log_dict['job_run_id']}-{epoch}"
        self.log_dict["log_entry_time"] = datetime.now()
        self.log_dict["status"] = status
        # self.log_dict["bdp_date_id"] = int(datetime.now().strftime("%Y%m%d"))

        # Calculate bdp_ingestion_id
        base_date = datetime.strptime("2019-12-05", "%Y-%m-%d")
        current_date = datetime.today()
        days_diff = (current_date - base_date).days
        self.log_dict["bdp_ingestion_id"] = days_diff

        log_df = spark.createDataFrame([self.log_dict], schema = schema)
        log_df.write.mode("append").insertInto(f"{target_db}.{table_name}")
        # logger.info(f"Success Logs written to the table: {table_name}")

class SQLExecutor:
    """Execute SQL queries using Spark and manage logging for query execution.

    - Initialize with a SparkSession and a logger instance.
    - Provide methods to read, format, and run SQL queries.
    - Support structured logging and error handling during execution.
    """

    def __init__(self, spark, logger, global_config = None):
        """Initialize the SQLExecutor with Spark session and logger.

        - Store the provided SparkSession instance.
        - Store the logger for logging SQL execution details.
        - Prepare the executor for running SQL queries using Spark.
        """
        self.spark = spark
        self.logger = logger
        self.global_config = global_config if global_config else {}

    def get_query(self, path, query_params, other_params=None):
        """Read and format SQL query from a file using global variables.

        - Open the SQL file at the given path.
        - Read its contents and substitute placeholders using parameters.
        - Merge query_params and other_params into a single dictionary.
        - Return the formatted SQL query string.
        """
        if other_params is None:
            other_params = {}
        with open(path, encoding="utf-8") as file:
            sql_query = file.read()
        all_params = {**vars(self.global_config), **query_params, **other_params}
        return Template(sql_query).substitute(all_params)


    def execute_query(self, query):
        """Execute a SQL query using Spark and log it."""
        df = self.spark.sql(query)
        return df

    def insert_overwrite(self, df, target_db, target_table, ingestion_id):
        """Overwrite Hive partition or drop it if DataFrame is empty."""
        if df.count() == 0:
                    drop_query = f"""
            ALTER TABLE {target_db}.{target_table}
            DROP IF EXISTS PARTITION (bdp_ingestion_id = '{ingestion_id}')
        """
            self.spark.sql(drop_query)
            self.logger.info(f"Dropped empty partition: {ingestion_id}")
        else:
            df.write.mode("overwrite").insertInto(f"{target_db}.{target_table}", overwrite=True)
            # self.logger.info(f"Inserted data into table: {target_db}.{target_table}")

    def get_schema(self, df):
        """Return schema structure as JSON string without metadata."""
        schema = [
            {"name": field.name, "type": field.dataType.simpleString(), "nullable": field.nullable}
            for field in df.schema.fields
        ]
        return json.dumps(schema)

    def process_df(self, df, query_json, ingestion_id=None):
        """Process DataFrame based on target strategy in config."""
        target_db = query_json["tgt_owner"]
        target_table = query_json["tgt_table"]
        row_count = df.count()
        total_col_count = len(df.columns)

        # if query_json["tgt_strategy"] == "Create_Temp_View":
        #     df.createOrReplaceTempView(query_json["tgt_table"])
        #     self.logger.info(f"Created temp view: {query_json['tgt_table']}")
        #else:
        self.insert_overwrite(df, query_json["tgt_owner"], query_json["tgt_table"], ingestion_id)
            # self.spark.sql(f"msck repair table {target_db}.{target_table}")
            # try:
            #     self.spark.sql(f"REFRESH TABLE {target_db}.{target_table}")
            # except Exception as e:
            #     self.logger.warning(f"Could not refresh table - {target_db}.{target_table} - {e}")

        return {"tgt_total_cols": total_col_count, "row_count": row_count}

def dict_to_namespace(obj):
    """Convert a dictionary into a SimpleNamespace object recursively.

    Args:
        obj (dict): The dictionary to convert.

    Returns:
        SimpleNamespace or original value: A nested SimpleNamespace if input is a dictionary, else the original value.

    """
    if isinstance(obj, dict):
        return SimpleNamespace(**{k: dict_to_namespace(v) for k, v in obj.items()})
    elif isinstance(obj, list):
        return [dict_to_namespace(item) for item in obj]
    else:
        return obj

def add_prefix(a):
    """Add a prefix 'P_' to the given value.

    Args:
        a (any): Value to prefix.

    Returns:
        str: Prefixed string.

    """
    return "P_" + str(a)

'''
def get_partitions(run_date, total_no_of_days):
    """Calculate full and incremental partition identifiers based on run date and number of days to look back.

    Args:
        run_date (str): The run date in 'YYYY-MM-DD' format.
        total_no_of_days (int): Number of days to look back for incremental partitions.

    Returns:
        JSON: Full partition string, incremental partitions and run_date.

    """
    # today_date = run_date.strftime("%Y-%m-%d 23:59:59.9")
    full_partition = "P_" + str(spark.sql(f"SELECT CAST(datediff(to_date('{run_date}'), to_date('2019-12-05')) AS STRING) bdp_partition_id").collect()[0][0])
    part_dt_fmt = run_date - timedelta(days=int(total_no_of_days))
    start_date = (datetime.strptime(part_dt_fmt.strftime("%Y-%m-%d"), "%Y-%m-%d"))
    end_date = run_date.strftime("%Y-%m-%d 23:59:59.9")
    start_partition_num = spark.sql(f"SELECT  CAST(datediff(to_date('{start_date}'), to_date('2019-12-05')) AS STRING) bdp_partition_id").collect()[0][0]
    end_partition_num = spark.sql(f"SELECT CAST(datediff(to_date('{end_date}'), to_date('2019-12-05')) AS STRING) bdp_partition_id").collect()[0][0]
    partitions = list(range(int(start_partition_num), int(end_partition_num) + 1))
    inc_partitions = "('P_" + str(partitions[0]) + "')" if len(partitions) == 1 else tuple(map(add_prefix, partitions))
    # run_date = datetime.strptime(run_date, "%Y-%m-%d")

    return {
        "latest_partition": f"'{full_partition}'",
        "past_partitions": inc_partitions,
        "run_date": run_date
    }
'''
def parse_spark_configuration(spark):
    """Extract Spark configuration details and return them in a structured dictionary.

    - Access the SparkContext from the provided SparkSession.
    - Retrieve the Spark configuration object.
    - Log the Spark configuration using the custom logger.
    - Extract specific configuration values such as the job run ID and principal.
    - Return a dictionary containing the configuration, loaded principal, job run ID, and log level.
    """
    sc = spark._sc
    spark_config = sc.getConf()
    cmf.print_spark_logs(spark_config, logger)
    log_level = "INFO"

    return {
        "spark_config": spark_config,
        "loaded_by": sc.getConf().get("spark.hadoop.yarn.resourcemanager.principal", ""),
        "job_run_id": sc.getConf().get("spark.kubernetes.driver.label.dex-job-run-id", ""),
        "log_level": log_level
    }

def get_partition_id(run_date):
    """Generate a partition ID string based on the difference in days from a fixed start date.

    - Use Spark SQL to calculate the number of days between the run_date and '2019-12-05'.
    - Prefix the result with 'P_' to form the partition ID.
    - Return the partition ID string.
    """
    bdp_partition_id = spark.sql(f"SELECT concat('P_',CAST(datediff(to_date('{run_date}'), to_date('2019-12-05')) AS STRING)) bdp_partition_id").collect()[0][0]
    return bdp_partition_id

def add_query_config_to_logs(table_logger, query_json):
    """Log each key-value pair from the query configuration into the table logger.

    - Iterate through the query_json dictionary.
    - If the key starts with 'query_config', serialize its value using JSON.
    - Log each key and its corresponding value using the table_logger.
    """
    for key, value in query_json.items():
        if key.startswith("query_config"):
            str_value = json.dumps(value.__dict__)
            table_logger.add_log(key, str_value)
        else:
            table_logger.add_log(key, value)


def process(sql_executor, table_logger, spark_conf, global_config, control_config, job_config):
    """Execute jobs and queries defined in the configuration.

    Log execution details and handle success or failure outcomes.
    """
    table_logger.add_log("dag_name", control_config.dag_name)
    table_logger.add_log("dag_run_id", 17717)
    table_logger.add_log("spark_job_name", job_config.spark_job_name)
    table_logger.add_log("job_name", job_config.job_name)
    table_logger.add_log("job_run_id", int(spark_conf["job_run_id"]))
    table_logger.add_log("loaded_by", spark_conf["loaded_by"])

    run_date = datetime.strptime(control_config.run_date, "%Y-%m-%d") if control_config.run_date != "NA" else datetime.today()
    # Calculate ingestion_id as integer using the correct formula
    ingestion_id = spark.sql(f"SELECT CAST(datediff(to_date('{run_date}'), to_date('2019-12-05')) AS BIGINT) as ingestion_id").collect()[0][0]
    table_logger.add_log("run_date", str(control_config.run_date))

    logger.info(f"Starting job: {job_config.job_name}")

    queries = job_config.queries
    total_queries = len(queries)

    for idx, query in enumerate(queries, start=1):
        prefix = f"{idx}/{total_queries}"
        
        logger.info(f"{prefix} Starting query: {query.query_name}")
        
        add_query_config_to_logs(table_logger, query.__dict__)
        # if query.query_config.no_of_past_days != "NA":
        #     other_params = get_partitions(run_date, query.query_config.no_of_past_days)
        # else:
        other_params = {"run_date": run_date}

        query_params_json = query.query_config.__dict__
        start_time = datetime.now()
        table_logger.add_log("start_time", start_time)
        table_logger.post_logs(log_db, log_table, "STARTED")
        logger.info(f"{prefix} STARTED logs posted to the log table")

        try:
            # Build full query file path using global base path
            src_query_file_path = global_config.base_cde_mount_path + query.src_query_file_path
            logger.info("src_query_file_path :" + src_query_file_path)
            table_logger.add_log("src_query_file_path", src_query_file_path)

            sql_text = sql_executor.get_query(src_query_file_path, query_params_json, other_params)
            # logger.info("Executing Query: \n" + query)
            logger.info(f"{prefix} Executing Query:\n{sql_text}")
            
            df = sql_executor.execute_query(sql_text)
            df_details = sql_executor.process_df(df, query.__dict__, ingestion_id)

            # logger added, removed from insertOverwrite function (sub function of process_df)
            logger.info(f"{prefix} Inserted data into table: {query.tgt_owner}.{query.tgt_table}")

            end_time = datetime.now()
            table_logger.add_log("end_time", end_time)
            table_logger.add_log("tgt_total_cols", df_details["tgt_total_cols"])
            table_logger.add_log("row_count", df_details["row_count"])
            logger.info(f"{prefix} Executed query: {query.query_name} in job: {job_config.job_name}")
            logger.info(f"{prefix} Created/overwritten table: {query.tgt_table} with {df_details['row_count']} rows and {df_details['tgt_total_cols']} columns")
            table_logger.post_logs(log_db, log_table, "SUCCESS")
            logger.info(f"{prefix} Query completed successfully")

        except Exception as error:
            exception_handler = ExceptionHandler()
            exception_message = exception_handler.extract_error_message(error)
            end_time = datetime.now()
            table_logger.add_log("end_time", end_time)
            table_logger.add_log("exception_message", exception_message)
            table_logger.post_logs(log_db, log_table, "FAILED")
            logger.error(f"{prefix} Query failed with error: {exception_message}")
            raise error


spark = SparkSession.builder.appName("dpf_sql_executor").enableHiveSupport().getOrCreate()
spark.sql("set hive.exec.dynamic.partition.mode=nonstrict")
logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s - %(message)s")
logger = logging.getLogger(__name__)
spark_conf = parse_spark_configuration(spark)

global_config = json.loads(spark_conf["spark_config"].get("spark.custom_conf.global_variables"))
control_config = json.loads(spark_conf["spark_config"].get("spark.custom_conf.control_variables"))
job_config = json.loads(spark_conf["spark_config"].get("spark.custom_conf.job_variables"))
log_db = spark_conf["spark_config"].get("spark.custom_conf.log_db")
log_table = spark_conf["spark_config"].get("spark.custom_conf.log_table")

global_config = dict_to_namespace(global_config)
control_config = dict_to_namespace(control_config)
job_config = dict_to_namespace(job_config)

table_logger = DataFrameLogger()
sql_executor = SQLExecutor(spark, logger, global_config)

try:
    process(sql_executor, table_logger, spark_conf, global_config, control_config, job_config)
    logger.info("Job Completed Successfully")
except Exception as e:
    exception_handler = ExceptionHandler()
    exception_message = exception_handler.extract_error_message(e)
    end_time = datetime.now()
    table_logger.add_log("end_time", end_time)
    table_logger.add_log("exception_message", exception_message)
    table_logger.post_logs(log_db, log_table, "FAILED")
    raise e

