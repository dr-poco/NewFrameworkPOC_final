import json
import logging
import os
import smtplib
import sys
import tempfile
from datetime import datetime, timedelta
from email.mime.application import MIMEApplication
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
from string import Template
from types import SimpleNamespace

import control_monitor_framework as cmf
import pandas as pd
from jinja2 import Template as JTemplate
from pyspark.sql import SparkSession

# Add template directory to system path
sys.path.append("/app/mount/scripts/pyscripts/pylib_control_monitoring/")
sys.path.append("/app/mount/scripts/pyscripts/aos_framework/")

def render_template(base_cde_mount_path, mail_template_path, context):
    """Render an HTML template using Jinja2.

    Args:
        base_cde_mount_path (str): Base directory path where the template is stored.
        mail_template_path (str): File path of the template file.
        context (dict): Dictionary containing variables to populate the template.

    Returns:
        str: Rendered HTML string.

    """
    template_path = base_cde_mount_path + mail_template_path
    with open(template_path, encoding="utf-8") as file:
        template_str = file.read()
    template = JTemplate(template_str)
    return template.render(context)

def send_email(
    sender_email,
    receiver_email,
    cc_email,
    subject,
    base_cde_mount_path,
    mail_template_path,
    mail_description,
    attachment_paths=None,
    df=None
):
    """Send an HTML email with optional attachments and embedded table data.

    Args:
        sender_email (str): Sender's email address.
        receiver_email (str): Semicolon-separated string of recipient email addresses.
        cc_email (str): Semicolon-separated string of CC email addresses.
        subject (str): Subject of the email.
        base_cde_mount_path (str): Base directory path where the email template is stored.
        mail_template_path (str): File path of the email template.
        mail_description (str): Text description to insert into the email body.
        attachment_paths (list, optional): List of file paths to attach. Defaults to None.
        df (DataFrame, optional): Pandas DataFrame to embed in the template context. Defaults to None.

    """
    msg = MIMEMultipart()
    msg["From"] = sender_email
    msg["To"] = receiver_email
    msg["Cc"] = cc_email
    msg["Subject"] = subject

    to = receiver_email.split(";")
    cc = cc_email.split(";")
    recepient_mail = to + cc

    # Prepare context for Jinja2
    context = {
        "mail_description": mail_description
    }

    if df is not None and not df.empty:
        context["table"] = df

    # Render HTML body from template
    body_html = render_template(base_cde_mount_path, mail_template_path, context)
    msg.attach(MIMEText(body_html, "html"))

    # Attach files if any
    if attachment_paths:
        for file_path in attachment_paths:
            with open(file_path, "rb") as f:
                part = MIMEApplication(f.read(), Name=os.path.basename(file_path))
                part["Content-Disposition"] = f'attachment; filename="{os.path.basename(file_path)}"'
                msg.attach(part)

    # Send the email
    s = smtplib.SMTP(global_config.adib_smtp_server, port=int(global_config.adib_smtp_port))
    s.sendmail(sender_email, recepient_mail, msg.as_string())
    s.quit()

def get_query(path, query_params, other_params=None):
    """Read and format SQL query from a file using global variables."""
    with open(path, encoding="utf-8") as file:
        sql_query = file.read()

    if other_params is None:
            other_params = {}

    all_params = {**query_params, **other_params}
    return Template(sql_query).substitute(all_params)

def dict_to_namespace(obj):
    """Convert a dictionary into a SimpleNamespace object recursively.

    Args:
        obj (dict): The dictionary to convert.

    Returns:
        SimpleNamespace or original value: A nested SimpleNamespace if input is a dictionary, else the original value.

    """
    if isinstance(obj, dict):
        return SimpleNamespace(**{k: dict_to_namespace(v) for k, v in obj.items()})
    elif isinstance(obj, list):
        return [dict_to_namespace(item) for item in obj]
    else:
        return obj

def generate_no_anomalies_email(anomaly_date,full_subject):
    """Generate and log an email message indicating no anomalies were found.

    Args:
        anomaly_date (str): The date for which anomalies were checked.
        full_subject (str): The subject line for the email.

    Returns:
        str: The email body content describing the absence of anomalies.

    """
    mail_description = f"There are No anomalies Generated as of {anomaly_date}"
    logger.info("No anomalies found. Sending notification email without data.")
    send_email(
        global_config.email_from_addr, job_config.to_email,
        job_config.cc_email, full_subject, global_config.base_cde_mount_path,
        job_config.mail_template_path, mail_description
        )

def handle_type_1_email(spark, logger, control_config, job_config, t_1, full_subject):
    """Handle Type-1 email logic: send email with mail body anomalies only.

    Args:
        spark (SparkSession): Spark session for executing SQL queries.
        logger (Logger): Logger for logging messages.
        control_config (object): Configuration containing control metadata.
        job_config (object): Configuration containing job-specific settings.
        t_1 (str): Date string used in subject and queries.
        full_subject (str): Full email subject line.

    """
    # Construct query dynamically using table name and run_date
    table_name = job_config.mail_body_src_table
    run_date = control_config.run_date
    mail_body_rule_query = f"""
        SELECT * 
        FROM {table_name}
        WHERE bdp_ingestion_id = CAST(datediff(to_date('{run_date}'), to_date('2019-12-05')) AS BIGINT)
    """
    logger.info("mail_body_rule_query :" + str(mail_body_rule_query))

    mail_body_df = spark.sql(mail_body_rule_query)
    mail_body_df = mail_body_df.drop('bdp_ingestion_id')
    mail_body_count = mail_body_df.count()

    if mail_body_count == 0:
        generate_no_anomalies_email(t_1, full_subject)
    else:
        mail_body_pd_df = mail_body_df.toPandas()
        logger.info("Sending email with mail body anomalies only.")
        send_email(
            global_config.email_from_addr, job_config.to_email,
            job_config.cc_email, full_subject, global_config.base_cde_mount_path,
            job_config.mail_template_path, job_config.mail_description,
            attachment_paths=None, df=mail_body_pd_df
        )

def handle_type_2_email(spark, logger, control_config, job_config, t_1, full_subject, temp_dir):
    """Handle Type-2 email logic: generate Excel attachment and send email.

    Args:
        spark (SparkSession): Spark session for executing SQL queries.
        logger (Logger): Logger for logging messages.
        control_config (object): Configuration containing control metadata.
        job_config (object): Configuration containing job-specific settings.
        t_1 (str): Date string used in subject and queries.
        full_subject (str): Full email subject line.
        temp_dir (str): Temporary directory path for saving the Excel file.

    """
    excel_file = os.path.join(temp_dir, f"{control_config.control_number}_report.xlsx")
    excel_anomaly_count = 0

    with pd.ExcelWriter(excel_file) as writer:
        for sheet_config in job_config.mail_attachment_sheets:
            for sheet_name, table_name in sheet_config.__dict__.items():
                sheet_query = f"""
                    SELECT * FROM {table_name}
                    WHERE bdp_ingestion_id = CAST(datediff(to_date('{control_config.run_date}'), to_date('2019-12-05')) AS BIGINT)
                """
                sheet_df = spark.sql(sheet_query).drop('bdp_ingestion_id')
                sheet_pd_df = sheet_df.toPandas()
                sheet_pd_df.fillna(value="None", inplace=True)

                sheet_pd_df.to_excel(writer, sheet_name=sheet_name, header=True, index=False)
                logger.info(f"Added sheet '{sheet_name}' with {sheet_pd_df.shape[0]} rows")

                if sheet_df.count() > 0:
                    excel_anomaly_count = 1

    if excel_anomaly_count == 0:
        generate_no_anomalies_email(t_1, full_subject)
    else:
        logger.info(f"Attachment saved at: {excel_file}")
        logger.info("Sending email with attachment only.")
        send_email(
            global_config.email_from_addr, job_config.to_email,
            job_config.cc_email, full_subject, global_config.base_cde_mount_path,
            job_config.mail_template_path, job_config.mail_description,
            attachment_paths=[excel_file], df=None
        )

def handle_type_3_email(spark, logger, control_config, job_config, t_1, full_subject, temp_dir):
    """Handle Type-3 email logic: send email with both mail body anomalies and Excel attachment.

    Args:
        spark (SparkSession): Spark session for executing SQL queries.
        logger (Logger): Logger for logging messages.
        control_config (object): Configuration containing control metadata.
        job_config (object): Configuration containing job-specific settings.
        t_1 (str): Date string used in subject and queries.
        full_subject (str): Full email subject line.
        temp_dir (str): Temporary directory path for saving the Excel file.

    """
    # Construct query dynamically using table name and run_date
    table_name = job_config.mail_body_src_table
    run_date = control_config.run_date
    mail_body_rule_query = f"""
        SELECT * 
        FROM {table_name}
        WHERE bdp_ingestion_id = CAST(datediff(to_date('{run_date}'), to_date('2019-12-05')) AS BIGINT)
    """
    logger.info("mail_body_rule_query :" + str(mail_body_rule_query))
    mail_body_df = spark.sql(mail_body_rule_query).drop('bdp_ingestion_id')
    mail_body_count = mail_body_df.count()

    # Excel attachment
    excel_file = os.path.join(temp_dir, f"{control_config.control_number}_report.xlsx")
    excel_anomaly_count = 0

    with pd.ExcelWriter(excel_file) as writer:
        for sheet_config in job_config.mail_attachment_sheets:
            for sheet_name, table_name in sheet_config.__dict__.items():
                sheet_query = f"""
                    SELECT * FROM {table_name}
                    WHERE bdp_ingestion_id = CAST(datediff(to_date('{run_date}'), to_date('2019-12-05')) AS BIGINT)
                """
                logger.info("sheet_query :" + str(sheet_query))
                sheet_df = spark.sql(sheet_query).drop('bdp_ingestion_id')
                sheet_pd_df = sheet_df.toPandas()
                sheet_pd_df.fillna(value="None", inplace=True)

                sheet_pd_df.to_excel(writer, sheet_name=sheet_name, header=True, index=False)
                logger.info(f"Added sheet '{sheet_name}' with {sheet_pd_df.shape[0]} rows")

                if sheet_df.count() > 0:
                    excel_anomaly_count = 1

    if excel_anomaly_count == 0 and mail_body_count == 0:
        generate_no_anomalies_email(t_1, full_subject)
    else:
        mail_body_pd_df = mail_body_df.toPandas()
        logger.info(f"Attachment saved at: {excel_file}")
        logger.info("Sending email with mail body anomalies and attachment.")
        send_email(
            global_config.email_from_addr, job_config.to_email,
            job_config.cc_email, full_subject, global_config.base_cde_mount_path,
            job_config.mail_template_path, job_config.mail_description,
            attachment_paths=[excel_file], df=mail_body_pd_df
        )

def process(spark, logger, control_config, job_config, t_1):
    """Execute jobs and stages defined in the configuration."""
    temp_dir = tempfile.mkdtemp(prefix="control_report_")
    logger.info(f"Created directory: {temp_dir}")

    full_subject = f"{job_config.subject} : {job_config.department} {t_1} {job_config.criticality}"

    if job_config.mail_type == "Type-1":
        handle_type_1_email(spark, logger, control_config, job_config, t_1, full_subject)

    elif job_config.mail_type == "Type-2":
        handle_type_2_email(spark, logger, control_config, job_config, t_1, full_subject, temp_dir)

    elif job_config.mail_type == "Type-3":
        handle_type_3_email(spark, logger, control_config, job_config, t_1, full_subject, temp_dir)


spark = SparkSession.builder.appName("spark_move_files_driver_from_abfs").enableHiveSupport().getOrCreate()
logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s - %(message)s")
logger = logging.getLogger(__name__)

sc = spark._sc
spark_config = sc.getConf()
cmf.print_spark_logs(spark_config, logger)

global_config = json.loads(spark_config.get("spark.custom_conf.global_variables"))
control_config = json.loads(spark_config.get("spark.custom_conf.control_variables"))
job_config = json.loads(spark_config.get("spark.custom_conf.job_variables"))

global_config = dict_to_namespace(global_config)
control_config = dict_to_namespace(control_config)
job_config = dict_to_namespace(job_config)

t_1 = datetime.strptime(control_config.run_date, "%Y-%m-%d") - timedelta(days=1)
t_1 = t_1.strftime("%Y-%m-%d")

try:
    process(spark, logger,control_config, job_config, t_1)
    state = "success"
    logger.info("Job Completed Successfully")
except Exception as e:
    state = "failed"
    logger.error(e, exc_info=True, stack_info=True)
    raise e
