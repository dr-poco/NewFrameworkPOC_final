from datetime import timedelta
from airflow import DAG
from airflow.models import Variable
from airflow.operators.dummy_operator import DummyOperator
from airflow.operators.python import PythonOperator
from airflow.utils import timezone
from cloudera.cdp.airflow.operators.cde_operator import CDEJobRunOperator
from dateutil import parser
from airflow.exceptions import AirflowException
import jsonschema
from jsonschema import validate, ValidationError
import json
from collections import defaultdict

spark_variables = Variable.get("dag_dpf__cm_aos_3", deserialize_json=True)
json_schema = Variable.get("json_schema", deserialize_json=True)
global_variables = Variable.get("dpf_cm_global_variables", deserialize_json=True)

dagSchedule = Variable.get("cm_DagSchedule", deserialize_json=True)
control_monitor = Variable.get("cm_control_monitor", deserialize_json=True)
schedule = str(dagSchedule["cm_internal_controls"])
dag_alert_list = str(control_monitor["dag_alert_list"])

default_args = {
    "owner": "ADIB_COLLAB_AI",
    "email": [dag_alert_list],
    "email_on_failure": True,
    "email_on_retry": True,
    "depends_on_past": False,
    "start_date": parser.isoparse("2020-08-09T20:20:00.268Z").replace(tzinfo=timezone.utc),
    "retries": 0,
    "retry_delay": timedelta(minutes=30),
    "provide_context": True
}

dag = DAG(
    "dpf_cm_aos_control_3_dag",
    concurrency=3,
    schedule_interval=schedule,
    catchup=False,
    default_args=default_args,
    is_paused_upon_creation=True
)

def validate_json_schema(json_data, json_schema):
    try:
        validate(instance=json_data, schema=json_schema)
        print("Validation passed")
    except ValidationError as ve:
        raise AirflowException(f"JSON Schema validation failed: {ve.message}")

start = DummyOperator(task_id="start", dag=dag)

validate_json_task = PythonOperator(
    task_id="validate_json",
    dag=dag,
    python_callable=validate_json_schema,
    provide_context=True,
    op_kwargs={
        "json_data": spark_variables,
        "json_schema": json_schema
    }
)

validate_json_task >> table_load_check

prev_group = [table_load_check]
# Helper function to process any job section
def process_jobs(job_list, job_type):
    tasks_by_queue = defaultdict(list)
    for idx, job in enumerate(job_list):
        queue = job.get("queue", 99)
        task_id = job.get("job_name")
        spark_submit_config = job.get("spark_submit_config", {})
        job_name = job.get("spark_job_name")

        operator = CDEJobRunOperator(
            task_id=task_id,
            dag=dag,
            job_name=job_name,
            overrides={
                "spark": {
                    **spark_submit_config,
                    "conf": {
                        **spark_submit_config.get("conf", {}),
                        "spark.custom_conf.control_variables": json.dumps(spark_variables["control_variables"]),
                        "spark.custom_conf.job_variables": json.dumps(job),
                        "spark.custom_conf.global_variables": json.dumps(global_variables),
                        "spark.custom_conf.log_db": "ds_dashboard",
                        "spark.custom_conf.log_table": "dpf_processing_log"
                    }
                }
            },
            trigger_rule="all_success"
        )
        tasks_by_queue[queue].append(operator)

    # Chain tasks group by group
    global prev_group
    for queue in sorted(tasks_by_queue.keys()):
        current_group = tasks_by_queue[queue]
        for prev_task in prev_group:
            for curr_task in current_group:
                prev_task >> curr_task
        prev_group = current_group

# Process sql_jobs
process_jobs(
    spark_variables.get("sql_jobs", []),
    job_type="sql"
)

# Process normal_email_reports
process_jobs(
    spark_variables.get("normal_email_reports", []),
    job_type="email"
)

# Process user_specific_email_reports
process_jobs(
    spark_variables.get("user_specific_email_reports", []),
    job_type="user_email"
)

end = DummyOperator(task_id="end", dag=dag)
for task in prev_group:
    task >> end
