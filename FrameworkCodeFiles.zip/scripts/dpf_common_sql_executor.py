import sys

sys.path.append("/app/mount/scripts/pyscripts/pylib_control_monitoring/")
import ast
import json
import logging
from string import Template
import time
from datetime import datetime, timedelta
from types import SimpleNamespace

import control_monitor_framework as cmf
from pyspark.sql import SparkSession
from pyspark.sql.utils import AnalysisException
from pyspark.sql.types import StructType, StructField, StringType, IntegerType, DateType, TimestampType, DoubleType

class ExceptionHandler:
    @staticmethod
    def extract_error_message(exception):
        """
        Extract a clean error message from Spark SQL or general exceptions.
        """
        if isinstance(exception, AnalysisException):
            return exception.desc.split(";")[0].strip()        
        if exception.__class__.__name__ == "ParseException":
            return str(exception).split("\n")[0].strip()
        return str(exception).split("\n")[0].strip()

class DataFrameLogger:
    def __init__(self):
        # Define default keys in log dictionary
        self.log_dict = {
            "log_id": None,
            "dag_name": None,
            "dag_run_id": None,
            "job_name": None,
            "job_run_id": None,
            "stg_name": None,
            "run_date": None,
            "src_query_file_path": None,
            "tgt_owner": None,
            "tgt_table": None,
            "tgt_strategy": None,
            "start_time": None,
            "end_time": None,
            "status": None,
            "row_count": None,
            "loaded_by": None,
            "log_entry_time": None,
            "stg_description": None,
            "tgt_schema": None,
            "query_config": None,
            "exception_message": None,
            "bdp_date_id": None
        }
    
    def get_log_schema(self):
        """Return the schema definition for the dpf_processing_log Spark DataFrame.

        This schema defines fields used to log metadata from execution stages including timing,
        status, source and target table info, and partitioning by date.

        Returns:
            StructType: A Spark StructType object representing the expected schema.

        """
        log_schema = StructType([
            StructField("log_id", StringType(), True),
            StructField("dag_name", StringType(), True),
            StructField("dag_run_id", IntegerType(), True),
            StructField("job_name", StringType(), True),
            StructField("job_run_id", IntegerType(), True),
            StructField("stg_name", StringType(), True),
            StructField("run_date", StringType(), True),
            StructField("src_query_file_path", StringType(), True),
            StructField("tgt_owner", StringType(), True),
            StructField("tgt_table", StringType(), True),
            StructField("tgt_strategy", StringType(), True),
            StructField("start_time", TimestampType(), True),
            StructField("end_time", TimestampType(), True),
            StructField("status", StringType(), True),
            StructField("row_count", IntegerType(), True),
            StructField("loaded_by", StringType(), True),
            StructField("log_entry_time", TimestampType(), True),
            StructField("stg_description", StringType(), True),
            StructField("tgt_schema", StringType(), True),
            StructField("query_config", StringType(), True),
            StructField("exception_message", StringType(), True),
            StructField("bdp_date_id", IntegerType(), True)
        ])

        return log_schema
    def add_log(self, key, value):
        """
        Update the log dictionary with the provided key and value.
        Only predefined keys will be updated.
        """
        if key in self.log_dict:
            self.log_dict[key] = value

    def get_log(self):
        """
        Return the complete log dictionary.
        """
        return self.log_dict

    def post_logs(self, target_db, table_name, status):
        schema = self.get_log_schema()
        epoch = int(datetime.now().timestamp())
        self.log_dict['log_id'] = f"{self.log_dict['dag_run_id']}-{self.log_dict['job_run_id']}-{epoch}"
        self.log_dict['log_entry_time'] = datetime.now()
        self.log_dict['status'] = status
        self.log_dict['bdp_date_id'] = int(datetime.now().strftime("%Y%m%d"))
        
        log_df = spark.createDataFrame([self.log_dict], schema = schema)
        log_df.write.mode("append").insertInto(f"{target_db}.{table_name}")
        logger.info(f"Success Logs written to the table: {table_name}")

class SQLExecutor:
    def __init__(self, spark, logger):
        self.spark = spark
        self.logger = logger

    def get_query(self, path, query_params, other_params={}):
        """Read and format SQL query from a file using global variables."""
        with open(path, encoding="utf-8") as file:
            sql_query = file.read()
        all_params = {**query_params, **other_params}
        return Template(sql_query).substitute(all_params)

    def execute_query(self, query):
        """Execute a SQL query using Spark and log it."""
        df = self.spark.sql(query)
        return df

    def insert_overwrite(self, df, target_db, target_table, partition_id):
        """Overwrite Hive partition or drop it if DataFrame is empty."""
        if df.count() == 0:
            drop_query = f"""
                ALTER TABLE {target_db}.{target_table} 
                DROP IF EXISTS PARTITION (bdp_partition_id = '{partition_id}')
            """
            self.spark.sql(drop_query)
            self.logger.info(f"Dropped empty partition: {partition_id}")
        else:
            df.write.mode("overwrite").insertInto(f"{target_db}.{target_table}", overwrite=True)
            self.logger.info(f"Inserted data into table: {target_db}.{target_table}")

    def get_schema(self, df):
        """Return schema structure as JSON string without metadata."""
        schema = [
            {"name": field.name, "type": field.dataType.simpleString(), "nullable": field.nullable}
            for field in df.schema.fields
        ]
        return json.dumps(schema)

    def process_df(self, df, stage_json, partition_id=None):
        """Process DataFrame based on target strategy in config."""
        if stage_json['tgt_strategy'] == 'Create_Temp_View':
            df.createOrReplaceTempView(stage_json['tgt_table'])
            self.logger.info(f"Created temp view: {stage_json['tgt_table']}")
        else:
            self.insert_overwrite(df, stage_json['tgt_owner'], stage_json['tgt_table'], partition_id)
        row_count = df.count()
        schema_json = self.get_schema(df)
        return {"tgt_schema": schema_json, "row_count": row_count}

def dict_to_namespace(obj):
    """Convert a dictionary into a SimpleNamespace object recursively.

    Args:
        d (dict): The dictionary to convert.

    Returns:
        SimpleNamespace or original value: A nested SimpleNamespace if input is a dictionary, else the original value.

    """
    if isinstance(obj, dict):
        return SimpleNamespace(**{k: dict_to_namespace(v) for k, v in obj.items()})
    elif isinstance(obj, list):
        return [dict_to_namespace(item) for item in obj]
    else:
        return obj

def add_prefix(a):
    """Add a prefix 'P_' to the given value.

    Args:
        a (any): Value to prefix.

    Returns:
        str: Prefixed string.

    """
    return "P_" + str(a)

def get_partitions(run_date, totalNoOfDays):
    """Calculate full and incremental partition identifiers based on run date and number of days to look back.

    Args:
        run_date (str): The run date in 'YYYY-MM-DD' format.
        totalNoOfDays (int): Number of days to look back for incremental partitions.

    Returns:
        tuple: Full partition string and incremental partitions tuple.

    """
    # today_date = run_date.strftime("%Y-%m-%d 23:59:59.9")
    full_partition = "P_" + str(spark.sql(f"SELECT CAST(datediff(to_date('{run_date}'), to_date('2019-12-05')) AS STRING) bdp_partition_id").collect()[0][0])
    part_dt_fmt = run_date - timedelta(days=int(totalNoOfDays))
    start_date = (datetime.strptime(part_dt_fmt.strftime("%Y-%m-%d"), "%Y-%m-%d"))
    end_date = run_date.strftime("%Y-%m-%d 23:59:59.9")
    start_partition_num = spark.sql(f"SELECT  CAST(datediff(to_date('{start_date}'), to_date('2019-12-05')) AS STRING) bdp_partition_id").collect()[0][0]
    end_partition_num = spark.sql(f"SELECT CAST(datediff(to_date('{end_date}'), to_date('2019-12-05')) AS STRING) bdp_partition_id").collect()[0][0]
    partitions = list(range(int(start_partition_num), int(end_partition_num) + 1))
    inc_partitions = "('P_" + str(partitions[0]) + "')" if len(partitions) == 1 else tuple(map(add_prefix, partitions))
    # run_date = datetime.strptime(run_date, "%Y-%m-%d")

    return {
        "latest_partition": f"'{full_partition}'",
        "past_partitions": inc_partitions,
        "run_date": run_date
    }

def parse_spark_configuration(spark):
    sc = spark._sc
    spark_config = sc.getConf()
    cmf.print_spark_logs(spark_config, logger)
    log_level = 'INFO'

    return {
        'spark_config': spark_config,
        'loaded_by': sc.getConf().get('spark.hadoop.yarn.resourcemanager.principal', ''),
        'job_run_id': sc.getConf().get('spark.kubernetes.driver.label.dex-job-run-id', ''),
        'log_level': log_level
    }

def get_partition_id(run_date):
    bdp_partition_id = spark.sql(f"SELECT concat('P_',CAST(datediff(to_date('{run_date}'), to_date('2019-12-05')) AS STRING)) bdp_partition_id").collect()[0][0]
    return bdp_partition_id

def add_stage_config_to_logs(table_logger, stage_json):
    for key, value in stage_json.items():
        if key.startswith("query_config"):
            str_value = json.dumps(value.__dict__)
            table_logger.add_log(key, str_value)
        else:
            table_logger.add_log(key, value)


def process(sql_executor, table_logger, spark_conf, control_config, job_config):
    """Execute jobs and stages defined in the configuration.

    Log execution details and handle success or failure outcomes.
    """

    table_logger.add_log("dag_name", control_config.dag_name)
    table_logger.add_log("dag_run_id", 17717)
    table_logger.add_log("job_name", job_config.cde_job_name)
    table_logger.add_log("job_run_id", int(spark_conf['job_run_id']))
    table_logger.add_log("loaded_by", spark_conf['loaded_by'])

    run_date = datetime.strptime(control_config.run_date, "%Y-%m-%d") if control_config.run_date != "NA" else datetime.today()
    partition_id = get_partition_id(run_date)
    table_logger.add_log("run_date", str(control_config.run_date))
    
    logger.info(f"Starting job: {job_config.name}")
    
    stages = job_config.stages
    sorted_stages = sorted(stages, key=lambda x: x.order_of_execution)

    for stage in sorted_stages:
        add_stage_config_to_logs(table_logger, stage.__dict__)
        if stage.query_config.no_of_past_days != "NA":
            other_params = get_partitions(run_date, stage.query_config.no_of_past_days)
        else:
            other_params = {"run_date": run_date}

        query_params_json = stage.query_config.__dict__
        start_time = datetime.now()
        table_logger.add_log("start_time", start_time)
        table_logger.post_logs(control_config.log_db, control_config.log_table, "STARTED")
        logger.info("STARTED Logs has been posted to the log table!!!")

        try:
            query = sql_executor.get_query(stage.src_query_file_path, query_params_json, other_params)
            logger.info("Executing Query: \n" + query)
            df = sql_executor.execute_query(query)
            df_details = sql_executor.process_df(df, stage.__dict__, partition_id)
            end_time = datetime.now()
            table_logger.add_log("end_time", end_time)
            table_logger.add_log("tgt_schema", df_details['tgt_schema'])
            table_logger.add_log("row_count", df_details['row_count'])
            logger.info(f"Executed stage: {stage.stg_name} in job: {job_config.name}")
            table_logger.post_logs(control_config.log_db, control_config.log_table, "SUCCESS")
        except Exception as error:
            exception_handler = ExceptionHandler()
            exception_message = exception_handler.extract_error_message(error)
            end_time = datetime.now()
            table_logger.add_log("end_time", end_time)
            table_logger.add_log("exception_message", exception_message)
            table_logger.post_logs(control_config.log_db, control_config.log_table, "FAILED")


spark = SparkSession.builder.appName("dpf_sql_executor").enableHiveSupport().getOrCreate()
spark.sql("set hive.exec.dynamic.partition.mode=nonstrict")
logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s - %(message)s")
logger = logging.getLogger(__name__)
spark_conf = parse_spark_configuration(spark)
table_logger = DataFrameLogger()
sql_executor = SQLExecutor(spark, logger)

control_config = json.loads(spark_conf['spark_config'].get("spark.custom_conf.control_variables"))
job_config = json.loads(spark_conf['spark_config'].get("spark.custom_conf.job_variables"))

control_config = dict_to_namespace(control_config)
job_config = dict_to_namespace(job_config)

try:
    process(sql_executor, table_logger, spark_conf, control_config, job_config)
    logger.info("Job Completed Successfully")
except Exception as e:
    exception_handler = ExceptionHandler()
    exception_message = exception_handler.extract_error_message(e)
    end_time = datetime.now()
    table_logger.add_log("end_time", end_time)
    table_logger.add_log("exception_message", exception_message)
    table_logger.post_logs(control_config.log_db, control_config.log_table, "FAILED")
    raise e

