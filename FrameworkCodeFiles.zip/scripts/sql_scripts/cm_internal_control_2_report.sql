SELECT *
FROM ${ds_zone_db}.cm_internal_2_report_test