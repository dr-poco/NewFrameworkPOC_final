import ast
import json
import logging
import os
import smtplib
import sys
from datetime import datetime, timedelta
from email.mime.application import MIMEApplication
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
from types import SimpleNamespace
from string import Template as string_template
import pandas as pd
from jinja2 import Template as JTemplate
from pyspark.sql import SparkSession

import control_monitor_framework as cmf

# Add template directory to system path
sys.path.append("/app/mount/scripts/pyscripts/pylib_control_monitoring/")
sys.path.append("/app/mount/scripts/pyscripts/aos_framework/")

def render_template(template_root_dir, template_name, context):
    """Render an HTML template using Jinja2.

    Args:
        template_root_dir (str): Directory path where the template is stored.
        template_name (str): Name of the template file.
        context (dict): Dictionary containing variables to populate the template.

    Returns:
        str: Rendered HTML string.

    """
    template_path = template_root_dir + template_name
    with open(template_path, encoding="utf-8") as file:
        template_str = file.read()
    template = JTemplate(template_str)
    return template.render(context)

def send_email(
    sender_email,
    receiver_email,
    cc_email,
    subject,
    template_root_dir,
    template_name,
    mail_description,
    attachment_paths=None,
    df=None
):
    """Send an HTML email with optional attachments and embedded table data.

    Args:
        sender_email (str): Sender's email address.
        receiver_email (str): Semicolon-separated string of recipient email addresses.
        cc_email (str): Semicolon-separated string of CC email addresses.
        subject (str): Subject of the email.
        template_root_dir (str): Directory path where the email template is stored.
        template_name (str): Filename of the email template.
        mail_description (str): Text description to insert into the email body.
        attachment_paths (list, optional): List of file paths to attach. Defaults to None.
        df (DataFrame, optional): Pandas DataFrame to embed in the template context. Defaults to None.

    """
    msg = MIMEMultipart()
    msg["From"] = sender_email
    msg["To"] = receiver_email
    msg["Cc"] = cc_email
    msg["Subject"] = subject

    to = receiver_email.split(";")
    cc = cc_email.split(";")
    recepient_mail = to + cc

    # Prepare context for Jinja2
    context = {
        "mail_description": mail_description
    }

    if df is not None and not df.empty:
        context["table"] = df

    # Render HTML body from template
    body_html = render_template(template_root_dir, template_name, context)
    msg.attach(MIMEText(body_html, "html"))

    # Attach files if any
    if attachment_paths:
        for file_path in attachment_paths:
            with open(file_path, "rb") as f:
                part = MIMEApplication(f.read(), Name=os.path.basename(file_path))
                part["Content-Disposition"] = f'attachment; filename="{os.path.basename(file_path)}"'
                msg.attach(part)

    # Send the email
    s = smtplib.SMTP("smtp.adib.co.ae", port=25)
    s.sendmail(sender_email, recepient_mail, msg.as_string())
    s.quit()

def get_query(path, query_params, other_params={}):
    """Read and format SQL query from a file using global variables."""
    with open(path, encoding="utf-8") as file:
        sql_query = file.read()
    all_params = {**query_params, **other_params}
    return string_template(sql_query).substitute(all_params)

def dict_to_namespace(obj):
    """Convert a dictionary into a SimpleNamespace object recursively.

    Args:
        d (dict): The dictionary to convert.

    Returns:
        SimpleNamespace or original value: A nested SimpleNamespace if input is a dictionary, else the original value.

    """
    if isinstance(obj, dict):
        return SimpleNamespace(**{k: dict_to_namespace(v) for k, v in obj.items()})
    elif isinstance(obj, list):
        return [dict_to_namespace(item) for item in obj]
    else:
        return obj

def get_user_specific_df_details(df, user_column_name, user_value, to_mail_column_name, cc_column_name):
    # Filter the dataframe using the column name
    df_filtered = df[df[user_column_name] == user_value]

    # Get the first matching row
    row = df_filtered.iloc[0]

    # Access 'to' and 'cc' email values using column names
    to_email_address = row[to_mail_column_name]
    cc_email_address = row[cc_column_name]

    return df_filtered, to_email_address, cc_email_address

def generate_no_anomalies_email(anomaly_date,full_subject):
        mail_description = f"There are No anomalies Generated as of {anomaly_date}"
        logger.info("No anomalies found. Sending notification email without data.")
        send_email(
            job_config.email_from_addr, job_config.to_email,
            job_config.cc_email, full_subject, job_config.template_root_dir,
            job_config.mail_template, mail_description
            )

def process(spark, logger, control_config, job_config, t_1):
    """Execute jobs and stages defined in the configuration.

    Log execution details and handle success or failure outcomes.
    """
    os.makedirs("/tmp/control_report/", exist_ok=True)
    logger.info("Created directory: /tmp/control_report/")

    logger.info(f"Processing job: {job_config.name} | Department: {job_config.department} | Type: {job_config.mail_type}")

    sql_script_path = job_config.query_file_path + job_config.query_file_name
    mail_attach_rule_query = get_query(sql_script_path, job_config.query_config.__dict__, {"run_date": control_config.run_date})
    logger.info("Executing Query: \n" + mail_attach_rule_query)

    mail_attach_df = spark.sql(mail_attach_rule_query)
    mail_attach_count = mail_attach_df.count()
    logger.info(f"Mail attachment anomalies found: {mail_attach_count}")

    full_subject = f"{job_config.subject} : {job_config.department} {t_1} {job_config.criticality}"

    if mail_attach_count == 0:
        generate_no_anomalies_email(t_1,full_subject)
    else:
        # Common DataFrame conversion and user extraction
        mail_attach_pd_df = mail_attach_df.toPandas()
        group_by_column_name = job_config.user_grouping_columns.group_by_column
        unique_users = mail_attach_pd_df[group_by_column_name].unique().tolist()

        for user in unique_users:
            user_df, to_mail_list, cc_mail_list = get_user_specific_df_details(
                mail_attach_pd_df,
                job_config.user_grouping_columns.group_by_column,
                user,
                job_config.user_grouping_columns.to_email_column,
                job_config.user_grouping_columns.cc_email_column
            )

            if job_config.mail_type == "Type-1":
                logger.info("Sending email with mail body anomalies only.")
                send_email(
                    job_config.email_from_addr, to_mail_list,
                    cc_mail_list, full_subject, job_config.template_root_dir,
                    job_config.mail_template, job_config.mail_description,
                    attachment_paths=None, df=user_df
                )

            elif job_config.mail_type == "Type-2":
                excel_file = f"/tmp/control_report/{control_config.control_number}_{user}_{t_1}_report.xlsx"
                user_df.fillna(value="None", inplace=True)
                with pd.ExcelWriter(excel_file) as writer:
                    user_df.to_excel(writer, sheet_name="Sheet1", header=True, index=False)
                logger.info(f"Attachment saved at: {excel_file}")
                logger.info("Sending email with attachment only.")
                send_email(
                    job_config.email_from_addr, to_mail_list,
                    cc_mail_list, full_subject, job_config.template_root_dir,
                    job_config.mail_template, job_config.mail_description,
                    attachment_paths=[excel_file], df=None
                )

spark = SparkSession.builder.appName("dpf_sql_executor").enableHiveSupport().getOrCreate()
spark.sql("set hive.exec.dynamic.partition.mode=nonstrict")
logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s - %(message)s")
logger = logging.getLogger(__name__)
sc = spark._sc
spark_config = sc.getConf()
cmf.print_spark_logs(spark_config, logger)

control_config = json.loads(spark_config.get("spark.custom_conf.control_variables"))
job_config = json.loads(spark_config.get("spark.custom_conf.job_variables"))
control_config = dict_to_namespace(control_config)
job_config = dict_to_namespace(job_config)
t_1 = datetime.strptime(control_config.run_date, "%Y-%m-%d") - timedelta(days=1)
t_1 = t_1.strftime("%Y-%m-%d")

try:
    process(spark, logger,control_config, job_config, t_1)
    state = "success"
    logger.info("Job Completed Successfully")
except Exception as e:
    logger.error(e, exc_info=True, stack_info=True)
    raise e
