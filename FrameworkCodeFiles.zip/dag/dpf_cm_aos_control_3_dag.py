from datetime import timedelta

from airflow import DAG
from airflow.models import Variable
from airflow.operators.dummy_operator import DummyOperator
from airflow.operators.python import PythonOperator
from airflow.utils import timezone
from cloudera.cdp.airflow.operators.cde_operator import CDEJobRunOperator
from dateutil import parser
from airflow.exceptions import AirflowException
import jsonschema
from jsonschema import validate, ValidationError
import json

spark_variables = Variable.get("dpf_cm_aos_control_3_dag", deserialize_json=True)
json_schema = Variable.get("json_schema", deserialize_json=True)

dagSchedule = Variable.get("cm_DagSchedule", deserialize_json=True)
control_monitor = Variable.get("cm_control_monitor", deserialize_json=True)
schedule = str(dagSchedule["cm_internal_controls"])
dag_alert_list = str(control_monitor["dag_alert_list"])

default_args = {
    "owner": "ADIB_COLLAB_AI",
    "email": [dag_alert_list],
    "email_on_failure": True,
    "email_on_retry": True,
    "depends_on_past": False,
    "start_date": parser.isoparse("2020-08-09T20:20:00.268Z").replace(tzinfo=timezone.utc),
    "retries": 0,
    "retry_delay": timedelta(minutes=30),
    "provide_context": True
}

dag = DAG(
    "dpf_cm_aos_control_3_dag",
    concurrency=3,
    schedule_interval=schedule,
    catchup=False,
    default_args=default_args,
    is_paused_upon_creation=True
)

def validate_json_schema(json_data, json_schema):
    """
    Validates a JSON object against a JSON Schema.

    Args:
        json_data (dict): The JSON object to validate.
        schema (dict): The JSON Schema definition.

    Raises:
        AirflowException: If validation fails.
    """
    try:
        validate(instance=json_data, schema=json_schema)
        print("Validation passed")
    except ValidationError as ve:
        raise AirflowException(f"JSON Schema validation failed: {ve.message}")


start = DummyOperator(task_id="start", dag=dag)


validate_json_task = PythonOperator(
    task_id="validate_json",
    dag=dag,
    python_callable=validate_json_schema,
    provide_context=True,
    op_kwargs={
        "json_data": spark_variables,
        "json_schema": json_schema
    }
)

sql_job_1 = CDEJobRunOperator(
    task_id="preprocess_job",
    dag=dag,
    job_name="dpf_common_sql_executor",
    overrides={
        "spark": {
            "conf": {
                "spark.custom_conf.control_variables": json.dumps(spark_variables["control_variables"]),
                "spark.custom_conf.job_variables": json.dumps(spark_variables["sql_jobs"][0])
            }
        }
    },
    trigger_rule="all_success"
)


sql_job_2 = CDEJobRunOperator(
    task_id="detect_anomaly",
    dag=dag,
    job_name="dpf_common_sql_executor",
    overrides={
        "spark": {
            "conf": {
                "spark.custom_conf.control_variables": json.dumps(spark_variables["control_variables"]),
                "spark.custom_conf.job_variables": json.dumps(spark_variables["sql_jobs"][1])
            }
        }
    },
    trigger_rule="all_success"
)

email_report_job_1 = CDEJobRunOperator(
    task_id="email_report_job_1",
    dag=dag,
    job_name="dpf_email_sender",
    overrides={
        "spark": {
            "conf": {
                "spark.custom_conf.control_variables": json.dumps(spark_variables["control_variables"]),
                "spark.custom_conf.job_variables": json.dumps(spark_variables["normal_email_reports"][0])
            }
        }
    },
    trigger_rule="all_success"
)

email_report_job_2 = CDEJobRunOperator(
    task_id="email_report_job_2",
    dag=dag,
    job_name="dpf_email_sender",
    overrides={
        "spark": {
            "conf": {
                "spark.custom_conf.control_variables": json.dumps(spark_variables["control_variables"]),
                "spark.custom_conf.job_variables": json.dumps(spark_variables["normal_email_reports"][1])
            }
        }
    },
    trigger_rule="all_success"
)

email_report_job_3 = CDEJobRunOperator(
    task_id="email_report_job_3",
    dag=dag,
    job_name="dpf_email_sender",
    overrides={
        "spark": {
            "conf": {
                "spark.custom_conf.control_variables": json.dumps(spark_variables["control_variables"]),
                "spark.custom_conf.job_variables": json.dumps(spark_variables["normal_email_reports"][2])
            }
        }
    },
    trigger_rule="all_success"
)

user_specific_report_job_1 = CDEJobRunOperator(
    task_id="user_specific_report_job_1",
    dag=dag,
    job_name="dpf_user_specific_email_sender",
    overrides={
        "spark": {
            "conf": {
                "spark.custom_conf.control_variables": json.dumps(spark_variables["control_variables"]),
                "spark.custom_conf.job_variables": json.dumps(spark_variables["user_specific_email_reports"][0])
            }
        }
    },
    trigger_rule="all_success"
)

user_specific_report_job_2 = CDEJobRunOperator(
    task_id="user_specific_report_job_2",
    dag=dag,
    job_name="dpf_user_specific_email_sender",
    overrides={
        "spark": {
            "conf": {
                "spark.custom_conf.control_variables": json.dumps(spark_variables["control_variables"]),
                "spark.custom_conf.job_variables": json.dumps(spark_variables["user_specific_email_reports"][1])
            }
        }
    },
    trigger_rule="all_success"
)

end = DummyOperator(task_id="end", dag=dag)

# start >> run_jobs >> detect_anomaly_3_1 >> report_3_1 >> end
start >> validate_json_task >> sql_job_1 >> sql_job_2 >> email_report_job_1 >> email_report_job_2 >> email_report_job_3 >> user_specific_report_job_1 >> user_specific_report_job_2 >> end
