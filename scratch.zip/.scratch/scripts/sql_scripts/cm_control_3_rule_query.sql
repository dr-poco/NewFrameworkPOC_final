SELECT 
    Anomaly_id,
    rim_no,
    rim_status,
    resident,
    rim_class_code,
    acct_no,
    acct_status,
    acct_class_code,
    user_name,
    ethix_create_dt,
    BPM_create_dt,
    Reason,
    control_number,
    anomaly_date
FROM ${ds_zone_db}.cm_aos_3_1_final_report
WHERE anomaly_date = date_format('${run_date}', 'yyyy-MM-dd');
